import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Brain, Car, BarChart3, Zap } from "lucide-react";
import CarFeatureForm from "@/components/CarFeatureForm";
import PredictionResults from "@/components/PredictionResults";
import MLWorkflowExplanation from "@/components/MLWorkflowExplanation";

export interface CarFeatures {
  brand: string;
  horsepower: number;
  mileage: number;
  age: number;
  engineSize: number;
  fuelType: string;
  transmission: string;
  condition: string;
}

export interface PredictionResult {
  predictedPrice: number;
  confidence: number;
  features: CarFeatures;
  modelMetrics: {
    rmse: number;
    r2Score: number;
    mae: number;
  };
}

const Index = () => {
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const handlePrediction = (result: PredictionResult) => {
    setIsProcessing(true);
    setTimeout(() => {
      setPrediction(result);
      setIsProcessing(false);
    }, 2000); // Simulate ML processing time
  };

  return (
    <div className="min-h-screen bg-gradient-data">
      {/* Header */}
      <div className="bg-gradient-primary text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-3 mb-6">
            <Brain className="h-12 w-12" />
            <Car className="h-12 w-12" />
          </div>
          <h1 className="text-5xl font-bold mb-4">Car Price Prediction</h1>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Advanced Machine Learning Model for Accurate Vehicle Valuation
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
              <BarChart3 className="h-4 w-4 mr-2" />
              Regression Analysis
            </Badge>
            <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
              <Zap className="h-4 w-4 mr-2" />
              Feature Engineering
            </Badge>
            <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
              <Brain className="h-4 w-4 mr-2" />
              ML Pipeline
            </Badge>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {/* Feature Input */}
          <Card className="p-6 shadow-card">
            <h2 className="text-2xl font-bold mb-6 text-foreground flex items-center gap-3">
              <Car className="h-6 w-6 text-ml-primary" />
              Vehicle Features
            </h2>
            <CarFeatureForm onPredict={handlePrediction} isProcessing={isProcessing} />
          </Card>

          {/* Prediction Results */}
          <Card className="p-6 shadow-card">
            <h2 className="text-2xl font-bold mb-6 text-foreground flex items-center gap-3">
              <BarChart3 className="h-6 w-6 text-ml-secondary" />
              Price Prediction
            </h2>
            <PredictionResults prediction={prediction} isProcessing={isProcessing} />
          </Card>
        </div>

        {/* ML Workflow Explanation */}
        <MLWorkflowExplanation />
      </div>
    </div>
  );
};

export default Index;