import { CarFeatures, PredictionResult } from "@/pages/Index";

// Brand goodwill scores (simulated market data)
const brandGoodwillScores: Record<string, number> = {
  "Toyota": 0.85,
  "Honda": 0.82,
  "BMW": 0.90,
  "Mercedes-Benz": 0.92,
  "Audi": 0.88,
  "Ford": 0.75,
  "Chevrolet": 0.72,
  "Nissan": 0.78,
  "Hyundai": 0.74,
  "Volkswagen": 0.80,
  "Lexus": 0.89,
  "Mazda": 0.76,
  "Subaru": 0.79
};

// Fuel type multipliers
const fuelTypeMultipliers: Record<string, number> = {
  "gasoline": 1.0,
  "diesel": 1.15,
  "hybrid": 1.25,
  "electric": 1.35
};

// Transmission multipliers
const transmissionMultipliers: Record<string, number> = {
  "manual": 0.95,
  "automatic": 1.0,
  "cvt": 1.05
};

// Condition multipliers
const conditionMultipliers: Record<string, number> = {
  "excellent": 1.2,
  "good": 1.0,
  "fair": 0.8,
  "poor": 0.6
};

// Feature engineering functions
function calculateDepreciationFactor(age: number): number {
  // Exponential depreciation model
  return Math.exp(-0.15 * age);
}

function calculateMileageFactor(mileage: number): number {
  // Mileage impact on price (normalized)
  const avgMileagePerYear = 12000;
  const normalizedMileage = mileage / avgMileagePerYear;
  return Math.max(0.3, 1 - (normalizedMileage * 0.1));
}

function calculatePowerToWeightRatio(horsepower: number, engineSize: number): number {
  // Estimate car weight based on engine size (simplified)
  const estimatedWeight = 2500 + (engineSize * 300);
  return horsepower / estimatedWeight * 1000;
}

// Main prediction function - simulates a trained regression model
export function predictCarPrice(features: CarFeatures): PredictionResult {
  // Feature engineering
  const brandGoodwill = brandGoodwillScores[features.brand] || 0.75;
  const depreciationFactor = calculateDepreciationFactor(features.age);
  const mileageFactor = calculateMileageFactor(features.mileage);
  const fuelMultiplier = fuelTypeMultipliers[features.fuelType] || 1.0;
  const transmissionMultiplier = transmissionMultipliers[features.transmission] || 1.0;
  const conditionMultiplier = conditionMultipliers[features.condition] || 1.0;
  const powerToWeightRatio = calculatePowerToWeightRatio(features.horsepower, features.engineSize);

  // Base price calculation (simulated regression model)
  let basePrice = 
    15000 + // Base vehicle value
    (features.horsepower * 50) + // Horsepower contribution
    (features.engineSize * 3000) + // Engine size contribution
    (powerToWeightRatio * 100); // Performance factor

  // Apply all multipliers
  let predictedPrice = basePrice * 
    brandGoodwill * 
    depreciationFactor * 
    mileageFactor * 
    fuelMultiplier * 
    transmissionMultiplier * 
    conditionMultiplier;

  // Add some realistic variance
  const variance = 0.1; // 10% variance
  const randomFactor = 1 + (Math.random() - 0.5) * variance;
  predictedPrice *= randomFactor;

  // Round to nearest hundred
  predictedPrice = Math.round(predictedPrice / 100) * 100;

  // Calculate confidence based on feature completeness and model assumptions
  const confidence = Math.min(0.95, 
    0.7 + 
    (brandGoodwill * 0.1) + 
    (conditionMultiplier > 0.8 ? 0.1 : 0) +
    (features.mileage < 100000 ? 0.05 : 0)
  );

  // Simulated model metrics (would come from actual model training)
  const modelMetrics = {
    rmse: 3250, // Root Mean Square Error
    r2Score: 0.847, // R-squared score
    mae: 2100 // Mean Absolute Error
  };

  return {
    predictedPrice,
    confidence: Math.round(confidence * 100) / 100,
    features,
    modelMetrics
  };
}

// Additional utility functions for model explanation
export function getFeatureImportance() {
  return [
    { feature: "Brand Goodwill", importance: 0.25 },
    { feature: "Age/Depreciation", importance: 0.22 },
    { feature: "Mileage", importance: 0.18 },
    { feature: "Horsepower", importance: 0.15 },
    { feature: "Condition", importance: 0.12 },
    { feature: "Fuel Type", importance: 0.05 },
    { feature: "Engine Size", importance: 0.03 }
  ];
}

export function generatePriceRange(predictedPrice: number, confidence: number) {
  const errorMargin = predictedPrice * (1 - confidence) * 0.5;
  return {
    low: Math.round((predictedPrice - errorMargin) / 100) * 100,
    high: Math.round((predictedPrice + errorMargin) / 100) * 100
  };
}