import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CarFeatures, PredictionResult } from "@/pages/Index";
import { predictCarPrice } from "@/lib/mlModel";
import { Loader2, Settings } from "lucide-react";

interface CarFeatureFormProps {
  onPredict: (result: PredictionResult) => void;
  isProcessing: boolean;
}

const CarFeatureForm = ({ onPredict, isProcessing }: CarFeatureFormProps) => {
  const [features, setFeatures] = useState<CarFeatures>({
    brand: "",
    horsepower: 150,
    mileage: 50000,
    age: 3,
    engineSize: 2.0,
    fuelType: "",
    transmission: "",
    condition: ""
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = predictCarPrice(features);
    onPredict(result);
  };

  const carBrands = [
    "Toyota", "Honda", "BMW", "Mercedes-Benz", "Audi", "Ford", "Chevrolet", 
    "Nissan", "Hyundai", "Volkswagen", "Lexus", "Mazda", "Subaru"
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="brand">Brand</Label>
          <Select value={features.brand} onValueChange={(value) => 
            setFeatures({...features, brand: value})
          }>
            <SelectTrigger>
              <SelectValue placeholder="Select brand" />
            </SelectTrigger>
            <SelectContent>
              {carBrands.map(brand => (
                <SelectItem key={brand} value={brand}>{brand}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="horsepower">Horsepower</Label>
          <Input
            id="horsepower"
            type="number"
            value={features.horsepower}
            onChange={(e) => setFeatures({...features, horsepower: Number(e.target.value)})}
            min="80"
            max="800"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="mileage">Mileage (miles)</Label>
          <Input
            id="mileage"
            type="number"
            value={features.mileage}
            onChange={(e) => setFeatures({...features, mileage: Number(e.target.value)})}
            min="0"
            max="300000"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="age">Age (years)</Label>
          <Input
            id="age"
            type="number"
            value={features.age}
            onChange={(e) => setFeatures({...features, age: Number(e.target.value)})}
            min="0"
            max="30"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="engineSize">Engine Size (L)</Label>
          <Input
            id="engineSize"
            type="number"
            step="0.1"
            value={features.engineSize}
            onChange={(e) => setFeatures({...features, engineSize: Number(e.target.value)})}
            min="1.0"
            max="8.0"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="fuelType">Fuel Type</Label>
          <Select value={features.fuelType} onValueChange={(value) => 
            setFeatures({...features, fuelType: value})
          }>
            <SelectTrigger>
              <SelectValue placeholder="Select fuel type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="gasoline">Gasoline</SelectItem>
              <SelectItem value="diesel">Diesel</SelectItem>
              <SelectItem value="hybrid">Hybrid</SelectItem>
              <SelectItem value="electric">Electric</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="transmission">Transmission</Label>
          <Select value={features.transmission} onValueChange={(value) => 
            setFeatures({...features, transmission: value})
          }>
            <SelectTrigger>
              <SelectValue placeholder="Select transmission" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="manual">Manual</SelectItem>
              <SelectItem value="automatic">Automatic</SelectItem>
              <SelectItem value="cvt">CVT</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="condition">Condition</Label>
          <Select value={features.condition} onValueChange={(value) => 
            setFeatures({...features, condition: value})
          }>
            <SelectTrigger>
              <SelectValue placeholder="Select condition" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="excellent">Excellent</SelectItem>
              <SelectItem value="good">Good</SelectItem>
              <SelectItem value="fair">Fair</SelectItem>
              <SelectItem value="poor">Poor</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <Card className="p-4 bg-accent/50">
        <div className="flex items-center gap-2 mb-3">
          <Settings className="h-4 w-4 text-ml-accent" />
          <span className="font-medium text-sm">Feature Engineering</span>
        </div>
        <div className="flex flex-wrap gap-2">
          <Badge variant="outline">Brand Goodwill Score</Badge>
          <Badge variant="outline">Depreciation Model</Badge>
          <Badge variant="outline">Market Demand Index</Badge>
          <Badge variant="outline">Fuel Efficiency Rating</Badge>
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          These features are automatically calculated from your input data
        </p>
      </Card>

      <Button 
        type="submit" 
        className="w-full" 
        disabled={isProcessing || !features.brand || !features.fuelType || !features.transmission || !features.condition}
      >
        {isProcessing ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Processing ML Model...
          </>
        ) : (
          "Predict Car Price"
        )}
      </Button>
    </form>
  );
};

export default CarFeatureForm;