import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Database, 
  Settings, 
  BarChart3, 
  Target, 
  Brain, 
  Zap, 
  TrendingUp,
  CheckCircle2,
  ArrowRight
} from "lucide-react";

const MLWorkflowExplanation = () => {
  const workflowSteps = [
    {
      icon: Database,
      title: "Data Collection",
      description: "Gather comprehensive car data including brand, specifications, and market history",
      details: [
        "Vehicle specifications (horsepower, engine size, mileage)",
        "Market data (brand reputation, demand patterns)",
        "Historical pricing information",
        "Condition and maintenance records"
      ]
    },
    {
      icon: Settings,
      title: "Feature Engineering",
      description: "Transform raw data into meaningful features for machine learning",
      details: [
        "Brand goodwill score calculation",
        "Depreciation factor modeling",
        "Mileage impact normalization",
        "Power-to-weight ratio computation"
      ]
    },
    {
      icon: Brain,
      title: "Model Training",
      description: "Train regression models to learn price prediction patterns",
      details: [
        "Multiple linear regression implementation",
        "Cross-validation for model selection",
        "Hyperparameter optimization",
        "Feature importance analysis"
      ]
    },
    {
      icon: Target,
      title: "Model Evaluation",
      description: "Assess model performance using statistical metrics",
      details: [
        "R-squared score: 84.7% (variance explained)",
        "RMSE: $3,250 (prediction error)",
        "MAE: $2,100 (absolute error)",
        "Cross-validation accuracy testing"
      ]
    }
  ];

  const featureEngineering = [
    {
      name: "Brand Goodwill Score",
      description: "Quantifies brand reputation and market perception",
      formula: "Market Share × Customer Satisfaction × Reliability Index",
      impact: "25% of prediction accuracy"
    },
    {
      name: "Depreciation Factor",
      description: "Models how vehicle value decreases over time",
      formula: "e^(-0.15 × age)",
      impact: "22% of prediction accuracy"
    },
    {
      name: "Mileage Impact",
      description: "Normalizes mileage effect on vehicle value",
      formula: "max(0.3, 1 - (mileage/avg_annual_mileage × 0.1))",
      impact: "18% of prediction accuracy"
    },
    {
      name: "Performance Ratio",
      description: "Power-to-weight ratio indicating vehicle performance",
      formula: "horsepower / estimated_weight × 1000",
      impact: "15% of prediction accuracy"
    }
  ];

  const modelMetrics = [
    {
      metric: "R² Score",
      value: "0.847",
      description: "Percentage of variance in price explained by the model",
      interpretation: "84.7% of price variation is captured by our features"
    },
    {
      metric: "RMSE",
      value: "$3,250",
      description: "Root Mean Square Error - average prediction deviation",
      interpretation: "Typical prediction error of ±$3,250"
    },
    {
      metric: "MAE",
      value: "$2,100",
      description: "Mean Absolute Error - average absolute prediction error",
      interpretation: "50% of predictions within $2,100 of actual price"
    },
    {
      metric: "Cross-Validation",
      value: "5-Fold",
      description: "Model tested on multiple data splits for reliability",
      interpretation: "Consistent performance across different data samples"
    }
  ];

  return (
    <Card className="p-8 shadow-ml">
      <div className="text-center mb-8">
        <div className="flex items-center justify-center gap-3 mb-4">
          <Brain className="h-8 w-8 text-ml-primary" />
          <h2 className="text-3xl font-bold">Machine Learning Pipeline</h2>
        </div>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Understanding the complete workflow from data collection to price prediction
        </p>
      </div>

      <Tabs defaultValue="workflow" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="workflow">Workflow</TabsTrigger>
          <TabsTrigger value="features">Features</TabsTrigger>
          <TabsTrigger value="model">Model</TabsTrigger>
          <TabsTrigger value="metrics">Metrics</TabsTrigger>
        </TabsList>

        <TabsContent value="workflow" className="mt-6">
          <div className="grid md:grid-cols-2 gap-6">
            {workflowSteps.map((step, index) => (
              <Card key={index} className="p-6 relative">
                <div className="flex items-start gap-4">
                  <div className="p-3 rounded-lg bg-ml-primary/10">
                    <step.icon className="h-6 w-6 text-ml-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-lg font-semibold">{step.title}</h3>
                      <Badge variant="outline">{index + 1}</Badge>
                    </div>
                    <p className="text-muted-foreground mb-3">{step.description}</p>
                    <ul className="space-y-1">
                      {step.details.map((detail, i) => (
                        <li key={i} className="flex items-center gap-2 text-sm">
                          <CheckCircle2 className="h-3 w-3 text-ml-success" />
                          {detail}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                {index < workflowSteps.length - 1 && (
                  <ArrowRight className="h-5 w-5 text-muted-foreground absolute -bottom-2 right-6 md:hidden" />
                )}
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="features" className="mt-6">
          <div className="grid gap-6">
            <div className="text-center mb-6">
              <h3 className="text-xl font-semibold mb-2">Feature Engineering Process</h3>
              <p className="text-muted-foreground">
                Converting raw car data into predictive features for machine learning
              </p>
            </div>
            {featureEngineering.map((feature, index) => (
              <Card key={index} className="p-6">
                <div className="grid md:grid-cols-3 gap-4">
                  <div>
                    <h4 className="font-semibold text-lg mb-2">{feature.name}</h4>
                    <p className="text-muted-foreground text-sm">{feature.description}</p>
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground mb-1">Formula</p>
                    <code className="text-sm bg-muted p-2 rounded font-mono block">
                      {feature.formula}
                    </code>
                  </div>
                  <div className="flex items-center">
                    <div>
                      <p className="text-xs text-muted-foreground mb-1">Model Impact</p>
                      <Badge variant="secondary" className="bg-ml-primary/10 text-ml-primary">
                        <TrendingUp className="h-3 w-3 mr-1" />
                        {feature.impact}
                      </Badge>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="model" className="mt-6">
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-2">Regression Model Architecture</h3>
              <p className="text-muted-foreground">
                Multiple linear regression with engineered features for optimal price prediction
              </p>
            </div>
            
            <Card className="p-6">
              <h4 className="font-semibold mb-4 flex items-center gap-2">
                <Zap className="h-5 w-5 text-ml-accent" />
                Model Equation
              </h4>
              <div className="bg-muted p-4 rounded-lg font-mono text-sm">
                <p className="mb-2">Price = BasePrice × BrandGoodwill × DepreciationFactor × MileageFactor</p>
                <p className="mb-2">       × FuelMultiplier × TransmissionMultiplier × ConditionMultiplier</p>
                <p className="text-xs text-muted-foreground mt-2">
                  Where BasePrice = 15,000 + (Horsepower × 50) + (EngineSize × 3,000) + (PowerRatio × 100)
                </p>
              </div>
            </Card>

            <div className="grid md:grid-cols-2 gap-4">
              <Card className="p-4">
                <h5 className="font-semibold mb-3">Training Process</h5>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-ml-success" />
                    Data preprocessing and normalization
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-ml-success" />
                    Feature selection and engineering
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-ml-success" />
                    Model training with cross-validation
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-ml-success" />
                    Hyperparameter optimization
                  </li>
                </ul>
              </Card>
              
              <Card className="p-4">
                <h5 className="font-semibold mb-3">Model Features</h5>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-ml-success" />
                    Real-time price prediction
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-ml-success" />
                    Confidence interval calculation
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-ml-success" />
                    Feature importance analysis
                  </li>
                  <li className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-ml-success" />
                    Market trend adaptation
                  </li>
                </ul>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="metrics" className="mt-6">
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-2">Model Performance Metrics</h3>
              <p className="text-muted-foreground">
                Statistical measures of prediction accuracy and model reliability
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              {modelMetrics.map((metric, index) => (
                <Card key={index} className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h4 className="text-lg font-semibold">{metric.metric}</h4>
                      <p className="text-2xl font-bold text-ml-primary">{metric.value}</p>
                    </div>
                    <BarChart3 className="h-6 w-6 text-muted-foreground" />
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{metric.description}</p>
                  <p className="text-sm font-medium">{metric.interpretation}</p>
                </Card>
              ))}
            </div>

            <Card className="p-6 bg-gradient-secondary text-white">
              <h4 className="text-lg font-semibold mb-4">Real-World Applications</h4>
              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <h5 className="font-semibold mb-2">Automotive Industry</h5>
                  <p className="text-sm text-white/80">
                    Dealers use ML for inventory pricing and trade-in valuations
                  </p>
                </div>
                <div>
                  <h5 className="font-semibold mb-2">Insurance</h5>
                  <p className="text-sm text-white/80">
                    Accurate vehicle valuation for coverage and claims processing
                  </p>
                </div>
                <div>
                  <h5 className="font-semibold mb-2">Financial Services</h5>
                  <p className="text-sm text-white/80">
                    Loan decisions based on collateral value assessment
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </Card>
  );
};

export default MLWorkflowExplanation;