import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { PredictionResult } from "@/pages/Index";
import { getFeatureImportance, generatePriceRange } from "@/lib/mlModel";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { DollarSign, TrendingUp, Target, Award, Loader2 } from "lucide-react";

interface PredictionResultsProps {
  prediction: PredictionResult | null;
  isProcessing: boolean;
}

const PredictionResults = ({ prediction, isProcessing }: PredictionResultsProps) => {
  if (isProcessing) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-center">
        <Loader2 className="h-12 w-12 animate-spin text-ml-primary mb-4" />
        <h3 className="text-lg font-semibold mb-2">Processing ML Model</h3>
        <p className="text-muted-foreground text-sm">
          Running regression analysis and feature engineering...
        </p>
      </div>
    );
  }

  if (!prediction) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-center">
        <Target className="h-12 w-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-semibold mb-2">Ready for Prediction</h3>
        <p className="text-muted-foreground text-sm">
          Fill in the vehicle features to get an AI-powered price prediction
        </p>
      </div>
    );
  }

  const featureImportance = getFeatureImportance();
  const priceRange = generatePriceRange(prediction.predictedPrice, prediction.confidence);
  
  const COLORS = ['#0ea5e9', '#10b981', '#8b5cf6', '#f59e0b', '#ef4444', '#06b6d4', '#84cc16'];

  return (
    <div className="space-y-6">
      {/* Main Prediction */}
      <Card className="p-6 bg-gradient-primary text-white">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <DollarSign className="h-8 w-8" />
            <div>
              <h3 className="text-2xl font-bold">
                ${prediction.predictedPrice.toLocaleString()}
              </h3>
              <p className="text-white/80">Predicted Market Value</p>
            </div>
          </div>
          <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
            {(prediction.confidence * 100).toFixed(0)}% Confidence
          </Badge>
        </div>
        
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-white/70">Price Range</p>
            <p className="font-semibold">
              ${priceRange.low.toLocaleString()} - ${priceRange.high.toLocaleString()}
            </p>
          </div>
          <div>
            <p className="text-white/70">Model Accuracy (R²)</p>
            <p className="font-semibold">{(prediction.modelMetrics.r2Score * 100).toFixed(1)}%</p>
          </div>
        </div>
      </Card>

      {/* Model Metrics */}
      <div className="grid grid-cols-3 gap-4">
        <Card className="p-4 text-center">
          <TrendingUp className="h-6 w-6 text-ml-primary mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">RMSE</p>
          <p className="font-bold">${prediction.modelMetrics.rmse.toLocaleString()}</p>
        </Card>
        <Card className="p-4 text-center">
          <Target className="h-6 w-6 text-ml-secondary mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">MAE</p>
          <p className="font-bold">${prediction.modelMetrics.mae.toLocaleString()}</p>
        </Card>
        <Card className="p-4 text-center">
          <Award className="h-6 w-6 text-ml-accent mx-auto mb-2" />
          <p className="text-sm text-muted-foreground">Confidence</p>
          <p className="font-bold">{(prediction.confidence * 100).toFixed(0)}%</p>
        </Card>
      </div>

      {/* Feature Importance Chart */}
      <Card className="p-6">
        <h4 className="text-lg font-semibold mb-4">Feature Importance Analysis</h4>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={featureImportance}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="feature" 
                tick={{ fontSize: 12 }}
                angle={-45}
                textAnchor="end"
                height={60}
              />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip 
                formatter={(value: number) => [`${(value * 100).toFixed(1)}%`, 'Importance']}
              />
              <Bar dataKey="importance" fill="#0ea5e9" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      {/* Feature Distribution */}
      <Card className="p-6">
        <h4 className="text-lg font-semibold mb-4">Model Feature Distribution</h4>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={featureImportance}
                dataKey="importance"
                nameKey="feature"
                cx="50%"
                cy="50%"
                outerRadius={80}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
              >
                {featureImportance.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value: number) => `${(value * 100).toFixed(1)}%`} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </Card>

      {/* Confidence Meter */}
      <Card className="p-6">
        <h4 className="text-lg font-semibold mb-4">Prediction Confidence</h4>
        <div className="space-y-3">
          <div className="flex justify-between text-sm">
            <span>Model Confidence</span>
            <span>{(prediction.confidence * 100).toFixed(0)}%</span>
          </div>
          <Progress value={prediction.confidence * 100} className="h-3" />
          <p className="text-xs text-muted-foreground">
            Based on data quality, feature completeness, and model training accuracy
          </p>
        </div>
      </Card>
    </div>
  );
};

export default PredictionResults;